#!/usr/bin/env python3
"""
QuantumSafeVPN — Windows Wi-Fi to WSL Port 7000 Bridge
======================================================
Detects your local Wi-Fi IP address on Windows, binds to PORT 7000,
and forwards all incoming phone connections directly to the WSL2 VPN server.
"""

import socket
import threading
import sys
import time

def get_wifi_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "0.0.0.0"

def forward_stream(src, dst):
    try:
        while True:
            data = src.recv(65536)
            if not data:
                break
            dst.sendall(data)
    except Exception:
        pass
    finally:
        try: src.close()
        except: pass
        try: dst.close()
        except: pass

def handle_client(phone_sock, phone_addr, wsl_target):
    print(f"\n[+] [BRIDGE] New phone connection from {phone_addr}")
    try:
        wsl_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        wsl_sock.connect(wsl_target)
        print(f"[+] [BRIDGE] Successfully connected to WSL server {wsl_target}")
    except Exception as e:
        print(f"[!] [BRIDGE] Could not connect to WSL server {wsl_target}: {e}")
        phone_sock.close()
        return

    t1 = threading.Thread(target=forward_stream, args=(phone_sock, wsl_sock), daemon=True)
    t2 = threading.Thread(target=forward_stream, args=(wsl_sock, phone_sock), daemon=True)
    t1.start()
    t2.start()

def main():
    wifi_ip = get_wifi_ip()
    port = 7000
    wsl_target = ("127.0.0.1", port)

    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

    # Try binding to specific Wi-Fi IP, fallback to 0.0.0.0
    try:
        server.bind((wifi_ip, port))
        bound_ip = wifi_ip
    except Exception:
        server.bind(("0.0.0.0", port))
        bound_ip = "0.0.0.0"

    server.listen(10)
    print("=" * 65)
    print("   [+] QuantumSafeVPN Windows-to-WSL Bridge is RUNNING!")
    print("=" * 65)
    print(f"  Laptop Wi-Fi IP  : {wifi_ip}")
    print(f"  Listening On    : {bound_ip}:{port}")
    print(f"  Forwarding To   : WSL2 Linux ({wsl_target[0]}:{wsl_target[1]})")
    print("=" * 65)
    print(f"\n[+] In your Android app, enter Server IP: {wifi_ip}")
    print("   and Port: 7000, then click CONNECT.\n")

    while True:
        try:
            phone_sock, phone_addr = server.accept()
            threading.Thread(target=handle_client, args=(phone_sock, phone_addr, wsl_target), daemon=True).start()
        except KeyboardInterrupt:
            break
        except Exception as e:
            print(f"[!] Error: {e}")
            time.sleep(0.5)

if __name__ == "__main__":
    main()
