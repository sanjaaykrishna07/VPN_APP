import os
import struct
import subprocess
import sys
import time

try:
    import fcntl
    HAS_FCNTL = True
except ImportError:
    HAS_FCNTL = False

TUNSETIFF = 0x400454CA
IFF_TUN = 0x0001
IFF_NO_PI = 0x1000


class TunInterface:

    def __init__(self, name="tun0"):
        self.name = name
        self.fd = None
        self.is_virtual = not HAS_FCNTL or sys.platform == "win32"

    def create(self):
        if not self.is_virtual:
            try:
                self.fd = os.open(
                    "/dev/net/tun",
                    os.O_RDWR
                )

                interface = struct.pack(
                    "16sH",
                    self.name.encode(),
                    IFF_TUN | IFF_NO_PI
                )

                result = fcntl.ioctl(
                    self.fd,
                    TUNSETIFF,
                    interface
                )

                actual_name = result[:16].split(
                    b"\x00",
                    1
                )[0].decode()

                self.name = actual_name
                print(f"[+] TUN interface created: {self.name}")
                return self.fd
            except Exception as e:
                print(f"[*] /dev/net/tun unavailable ({e}). Using virtual TUN device.")
                self.is_virtual = True

        self.fd = 999  # Virtual handle
        print(f"[+] Virtual TUN interface created: {self.name}")
        return self.fd

    def configure(self, address):
        print(f"[*] Configuring {self.name} with {address}")
        if not self.is_virtual:
            try:
                subprocess.run(
                    ["ip", "addr", "replace", address, "dev", self.name],
                    check=True
                )
                subprocess.run(
                    ["ip", "link", "set", self.name, "up"],
                    check=True
                )
            except Exception as e:
                print(f"[!] Network configuration note: {e}")

        print(f"[+] {self.name} configured: {address}")

    def read_packet(self):
        if self.fd is None:
            raise RuntimeError("TUN interface is not created")

        if self.is_virtual:
            time.sleep(1)
            # Simulated ICMP/IP packet for demonstration
            return b"E\x00\x004\x00\x00@\x00@\x01\x00\x00\n\x08\x00\x02\n\x08\x00\x01QuantumSafeVPN-Data-Packet"

        return os.read(self.fd, 65535)

    def write_packet(self, packet):
        if self.fd is None:
            raise RuntimeError("TUN interface is not created")

        if not packet:
            return

        if self.is_virtual:
            return

        os.write(self.fd, packet)

    def close(self):
        if self.fd is not None and not self.is_virtual:
            try:
                os.close(self.fd)
            except OSError:
                pass
        self.fd = None
