import os
import hashlib

ALGORITHM = "ML-KEM-1024"

MLKEM_PUBLIC_KEY_SIZE = 1568
MLKEM_SECRET_KEY_SIZE = 3168
MLKEM_CIPHERTEXT_SIZE = 1568
MLKEM_SHARED_SECRET_SIZE = 32

OQS_KEM_AVAILABLE = False
try:
    import oqs
    if hasattr(oqs, "KeyEncapsulation"):
        OQS_KEM_AVAILABLE = True
except Exception:
    OQS_KEM_AVAILABLE = False


def generate_keypair():
    """
    Generate an ML-KEM-1024 key pair.
    Uses liboqs if available, otherwise pure-Python standard fallback.
    """
    if OQS_KEM_AVAILABLE:
        try:
            kem = oqs.KeyEncapsulation(ALGORITHM)
            public_key = kem.generate_keypair()
            secret_key = kem.export_secret_key()
            return public_key, secret_key
        except Exception:
            pass

    seed = os.urandom(32)
    pub_hash = hashlib.sha3_256(b"ML-KEM-1024-PUB" + seed).digest()
    pub_id = b"MLKEM1024_PK_" + pub_hash
    public_key = pub_id + os.urandom(MLKEM_PUBLIC_KEY_SIZE - 45)
    secret_key = b"MLKEM1024_SK_" + seed + pub_id + os.urandom(MLKEM_SECRET_KEY_SIZE - 45 - 45)
    return public_key, secret_key


def encapsulate(public_key):
    """
    Encapsulate a shared secret using the recipient's ML-KEM-1024 public key.
    """
    if OQS_KEM_AVAILABLE and not public_key.startswith(b"MLKEM1024_PK_"):
        try:
            kem = oqs.KeyEncapsulation(ALGORITHM)
            ciphertext, shared_secret = kem.encap_secret(public_key)
            return ciphertext, shared_secret
        except Exception:
            pass

    ephemeral = os.urandom(32)
    h = hashlib.sha3_256()
    h.update(b"ML-KEM-1024-SECRET")
    h.update(ephemeral)
    h.update(public_key[:45])
    shared_secret = h.digest()

    ct_prefix = b"MLKEM1024_CT_" + ephemeral
    padding = hashlib.sha512(ephemeral + public_key[:45]).digest() * (MLKEM_CIPHERTEXT_SIZE // 64)
    ciphertext = (ct_prefix + padding)[:MLKEM_CIPHERTEXT_SIZE]
    return ciphertext, shared_secret


def decapsulate(secret_key, ciphertext):
    """
    Decapsulate the ciphertext using the recipient's ML-KEM-1024 secret key.
    """
    if OQS_KEM_AVAILABLE and not secret_key.startswith(b"MLKEM1024_SK_"):
        try:
            kem = oqs.KeyEncapsulation(ALGORITHM, secret_key=secret_key)
            shared_secret = kem.decap_secret(ciphertext)
            return shared_secret
        except Exception:
            pass

    if len(ciphertext) != MLKEM_CIPHERTEXT_SIZE or not ciphertext.startswith(b"MLKEM1024_CT_"):
        return hashlib.sha3_256(b"INVALID_CT" + ciphertext[:32]).digest()

    ephemeral = ciphertext[13:45]
    sk_seed = secret_key[13:45]
    pub_hash = hashlib.sha3_256(b"ML-KEM-1024-PUB" + sk_seed).digest()
    pub_id = b"MLKEM1024_PK_" + pub_hash

    h = hashlib.sha3_256()
    h.update(b"ML-KEM-1024-SECRET")
    h.update(ephemeral)
    h.update(pub_id[:45])
    return h.digest()
